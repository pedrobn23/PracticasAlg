mkdir resultados ejecutable 2> /dev/null

cd hanoi
./compilar.sh
cd ../n2
./compilar.sh
cd ../n3
./compilar.sh
cd ../nlog
./compilar.sh

